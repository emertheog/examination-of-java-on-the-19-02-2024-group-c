/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project;

/**
 *
 * @author user
 */
public class Project {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
